setwd("C:\\Users\\IT24101714\\Desktop\\IT24101714\\LAB 04")
getwd()

data<-read.table("DATA 4.txt", header=TRUE,sep =" ")
fix(data)
attach(data)

##Part 2
##part a
boxplot(X1,main ="Box plot for team Attendence",outline = TRUE, Outpch = 8, horizontal = TRUE )
boxplot(X2,main="Box plot for team Salary",outline =TRUE,outpch=8,horizontal=TRUE)
boxplot(X3,main ="Box plot for years",outline = TRUE,outpch=8,horizontal=TRUE)

## Obtaining Histogram
hist(X1, ylab="Frequency", xlab="Team Attendance", main="Histogram for Team Attendance")
hist(X2, ylab="Frequency", xlab="Team Salary", main="Histogram for Team Salary")
hist(X3, ylab="Frequency", xlab="Years", main="Histogram for Years")

## Stem & Leaf Plot
stem(X1)
stem(X2)
stem(X3)

##Part b
##Mean
mean(X1)
mean(X2)
mean(X3)

##median
median(X1)
median(X2)s
median(X3)

##Standard Debitation
sd(X1)
sd(X2)
sd(X3)

## Part (c)

summary(X1)
summary(X2)SS
summary(X3)

summary(X1)

quantile(X1, 0.25)
quantile(X1, 0.75)

## Part (d)
IQR(X1)
IQR(X2)
IQR(X3)

## Part (e)
get.mode <- function(v) {
  counts <- table(v)
  mode <- as.numeric(names(counts[counts == max(counts)]))
  return(mode)
}
get.mode(X3)


branch_data <- read.csv("Exercise.txt")

boxplot(branch_data$Sales_X1, main="Sales (X1)")
fivenum(branch_data$Advertising_X2)  # or summary()
IQR(branch_data$Advertising_X2)
iqr_outliers <- function(x) {
  q1 <- quantile(x, 0.25, type=2); q3 <- quantile(x, 0.75, type=2)
  i <- IQR(x); lower <- q1 - 1.5*i; upper <- q3 + 1.5*i
  list(bounds=c(lower=lower, upper=upper), outliers=x[x<lower | x>upper])
}
iqr_outliers(branch_data$Years_X3)  # => no outliers



